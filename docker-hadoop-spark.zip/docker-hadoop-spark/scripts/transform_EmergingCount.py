from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, regexp_replace,when

# Initialize Spark session
spark = SparkSession.builder \
    .appName("Data Transformation") \
    .getOrCreate()

# Read the CSV file from HDFS
df = spark.read.option("header", "true").option("inferSchema", "true").csv("hdfs://namenode:9000/data/Data_BMC_cleaned/WEO_Emerging_markets.csv/part-00000-fc586399-55dd-4907-9315-62113908ae78-c000.csv")

# Clean the 'indicateur' field by removing anything after the first comma
df_cleaned = df.withColumn("indicateur", regexp_replace("Subject Descriptor", r",.*", ""))
renamed_df = df_cleaned.withColumn(
    "indicateur",
    when(df_cleaned.indicateur == "Gross domestic product", "PIB")
    .when(df_cleaned.indicateur == "Inflation", "Inflation")
    .when(df_cleaned.indicateur == "Current account balance", "solde_courant")
)

# Transform the data
transformed_df = renamed_df.withColumn("zone_geographique", lit("Emerging Markets")) \
    .selectExpr("Country as pays", "zone_geographique", "indicateur",
               "stack(12, '2017', `2017`, '2018', `2018`, '2019', `2019`, '2020', `2020`, '2021', `2021`, '2022', `2022`, '2023', `2023`, '2024', `2024`, '2025', `2025`, '2026', `2026`, '2027', `2027`, '2028', `2028`) as (annee, valeur)") \
    .where("valeur is not null")
# Pivot the data to create columns for each 'indicateur'
pivoted_df = transformed_df.groupBy("pays", "zone_geographique", "annee") \
    .pivot("indicateur", ["PIB", "Inflation", "solde_courant"]) \
    .agg({"valeur": "first"})  # Adjust aggregation logic as needed

# Sort the DataFrame by 'pays' in alphabetical order
sorted_df = pivoted_df.orderBy("pays")
single_file_df = sorted_df.coalesce(1)
# Save the transformed data to a CSV file in HDFS
output_path = "hdfs://namenode:9000/data/Data_BMC_transformed/WEO_Emerging_markets_transformed.csv"
single_file_df.write.mode("overwrite") \
    .option("header", "true") \
    .csv(output_path)

# Verify the data by loading the CSV and showing a few rows
verified_df = spark.read.option("header", "true").csv(output_path)
verified_df.show(20, truncate=False)

