from pyspark.sql import SparkSession
from pyspark.sql.functions import col, regexp_replace

# Initialize Spark session
spark = SparkSession.builder \
    .appName("DataCleaning") \
    .getOrCreate()

# HDFS input and output paths
input_files = [
    "hdfs://namenode:9000/data/Data_BMC/WEO_CountryGroups.csv",
    #"hdfs://namenode:9000/data/Data_BMC/WEO_Data.csv",
    #"hdfs://namenode:9000/data/Data_BMC/WEO_Emerging_markets.csv",
    #"hdfs://namenode:9000/data/Data_BMC/WEO_PaysAvances.csv",
    #"hdfs://namenode:9000/data/Data_BMC/WEO_ZoneUE.csv"
]
output_path = "hdfs://namenode:9000/data/Data_BMC_cleaned/"

# Process each file separately
for csv_file in input_files:
    # Extract just the file name from the full HDFS path
    file_name = csv_file.split("/")[-1]
    
    # Read the CSV file
    df = spark.read.option("header", "true").csv(csv_file)
    
    
    df.printSchema()
    df.show(5)
    
    # Drop rows where all elements are null
    df = df.dropna(how='all')
    
    # Drop rows where 'WEO Country Group Code' column has empty or null values
    df = df.filter(df['WEO Country Group Code'].isNotNull() & (df['WEO Country Group Code'] != ''))
    
    # Drop rows where 'WEO Country Group Code' column is not numeric
    df = df.filter(df['WEO Country Group Code'].rlike(r'^\d+$'))
    
    # Drop the specific column if it exists
    if "Country/Series-specific Notes" in df.columns:
        df = df.drop("Country/Series-specific Notes")
    
    # Check number of rows after cleaning
    num_rows = df.count()
    
    
    # Repartition to ensure a single output file
    df = df.coalesce(1)
    
    # Generate the output file path
    output_file = output_path + file_name
    
    # Write the cleaned data back to HDFS
    df.write.mode("overwrite").option("header", "true").csv(output_file)
    
    

# Stop the Spark session
spark.stop()
