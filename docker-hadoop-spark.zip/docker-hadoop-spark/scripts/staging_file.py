from pyspark.sql import SparkSession

# Initialize Spark session with Hive support
spark = SparkSession.builder \
    .appName("Combine Transformed Zone Files") \
    .enableHiveSupport() \
    .getOrCreate()

# List of transformed file paths for each zone
transformed_file_paths = [
    "hdfs://namenode:9000/data/Data_BMC_transformed/WEO_AllCountries_transformed.csv",
    "hdfs://namenode:9000/data/Data_BMC_transformed/WEO_Emerging_markets_transformed.csv",
    "hdfs://namenode:9000/data/Data_BMC_transformed/WEO_PaysAvances_transformed.csv",
    "hdfs://namenode:9000/data/Data_BMC_transformed/WEO_ZoneUE_transformed.csv"
]

# Initialize an empty DataFrame to hold combined data
combined_df = None

# Iterate over each transformed file and combine them
for file_path in transformed_file_paths:
    # Read each transformed CSV file
    df = spark.read.option("header", "true").csv(file_path)
    
    # Combine the DataFrames
    if combined_df is None:
        combined_df = df
    else:
        combined_df = combined_df.union(df)

# Coalesce to 1 partition to write to a single file
single_file_df = combined_df.coalesce(1)

# Write the combined data to a single CSV file in HDFS
output_path = "hdfs://namenode:9000/data/Data_BMC_transformed/WEO_Combined_Staging.csv"
single_file_df.write.mode("overwrite").option("header", "true") \
    .csv(output_path)

# Optional: Verify the combined data by showing some rows
combined_df.show(100)
