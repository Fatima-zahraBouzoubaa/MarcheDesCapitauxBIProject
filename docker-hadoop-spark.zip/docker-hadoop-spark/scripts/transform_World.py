from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, regexp_replace, when

# Initialize Spark session with Hive support
spark = SparkSession.builder \
    .appName("Data Transformation World") \
    .enableHiveSupport() \
    .getOrCreate()

# Read the CSV file from HDFS
df = spark.read.option("header", "true").option("inferSchema", "true") \
    .csv("hdfs://namenode:9000/data/Data_BMC_cleaned/WEO_AllCountries/part-00000-cf6eb528-dcc0-497e-be3c-d6e7a0cc4496-c000.csv")

# Clean the 'indicateur' field by removing anything after the first comma and renaming
df_cleaned = df.withColumn("indicateur", regexp_replace("Subject Descriptor", r",.*", ""))
renamed_df = df_cleaned.withColumn(
    "indicateur",
    when(df_cleaned.indicateur == "Gross domestic product", "PIB")
    .when(df_cleaned.indicateur == "Inflation", "Inflation")
    .when(df_cleaned.indicateur == "Current account balance", "solde_courant")
)

# Transform the data
transformed_df = renamed_df.withColumn("zone_geographique", lit("World")) \
    .selectExpr("Country as pays", "zone_geographique", "indicateur",
               "stack(12, '2017', `2017`, '2018', `2018`, '2019', `2019`, '2020', `2020`, '2021', `2021`, '2022', `2022`, '2023', `2023`, '2024', `2024`, '2025', `2025`, '2026', `2026`, '2027', `2027`, '2028', `2028`) as (annee, valeur)") \
    .where("valeur is not null")

# Pivot the data to create columns for each 'indicateur'
pivoted_df = transformed_df.groupBy("pays", "zone_geographique", "annee") \
    .pivot("indicateur", ["PIB", "Inflation", "solde_courant"]) \
    .agg({"valeur": "first"})  # Adjust aggregation logic as needed

# Sort the DataFrame by 'pays' in alphabetical order
sorted_df = pivoted_df.orderBy("pays")
single_file_df = sorted_df.coalesce(1)
# Write the transformed data to a CSV file in HDFS
single_file_df.write.mode("overwrite") \
    .option("header", "true") \
    .csv("hdfs://namenode:9000/data/Data_BMC_transformed/WEO_AllCountries_transformed.csv")

# Verify the data by reading the output CSV file back from HDFS (optional)
result_df = spark.read.option("header", "true") \
    .csv("hdfs://namenode:9000/data/Data_BMC_transformed/WEO_AllCountries_transformed.csv")

# Show the DataFrame in Spark
result_df.show(40, truncate=False)
