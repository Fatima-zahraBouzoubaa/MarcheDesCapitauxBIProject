from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("HiveIntegrationTest") \
    .enableHiveSupport() \
    .getOrCreate()

# Test with Hive
df = spark.sql("SHOW TABLES")
df.show()
