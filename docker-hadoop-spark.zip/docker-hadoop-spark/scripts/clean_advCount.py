from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when

# Initialize Spark session
spark = SparkSession.builder \
    .appName("DataCleaning") \
    .getOrCreate()

# HDFS input and output paths
input_file = "hdfs://namenode:9000/data/Data_BMC/WEO_PaysAvances.csv"
output_path = "hdfs://namenode:9000/data/Data_BMC_cleaned/WEO_PaysAvances"

# Read the CSV file
df = spark.read.option("header", "true").csv(input_file)

# Drop rows where all elements are null
df = df.dropna(how='all')

# Filter rows where 'WEO Country Code' column is either empty or not numeric
df = df.filter(df['WEO Country Code'].isNotNull() & (df['WEO Country Code'] != '') & df['WEO Country Code'].rlike(r'^\d+$'))

# Drop the 'Scale' and 'Country/Series-specific Notes' columns
df = df.drop("Scale", "Country/Series-specific Notes")

# Replace non-numeric values in year columns with null, preserving negative values
for year in range(2017, 2029):
    df = df.withColumn(
        str(year), 
        when(col(str(year)).rlike(r'^-?\d+(\.\d+)?$'), col(str(year)))  # Keep numeric and negative values
        .otherwise(None)  # Replace non-numeric values with null
    )

# Drop rows with any null values
df = df.dropna()

# Repartition to ensure a single output file
df = df.coalesce(1)

# Write the cleaned data back to HDFS
df.write.mode("overwrite").option("header", "true").csv(output_path)

# Stop the Spark session
spark.stop()
